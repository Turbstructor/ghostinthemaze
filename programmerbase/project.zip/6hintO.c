#include <stdio.h>

void main(){
    printf("vim을 사용해보자");
}