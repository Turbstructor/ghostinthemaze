#include <stdio.h>

void main(){
    printf("git clone을 사용해보자");
}