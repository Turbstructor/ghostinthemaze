#include <stdio.h>

void main(){
    printf("40번째 글자부터 43개의 글자까지");
}

