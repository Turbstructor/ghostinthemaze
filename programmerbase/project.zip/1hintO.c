#include <stdio.h>

void main(){
    printf("첫번째 힌트\n");
    printf("su를 이용하여 programmerbase로 로그인하자.\n");
    printf("password는 다음 퀴즈를 풀어서 찾아내자.\n");

    printf("1\t2\t3\n4\t5\t6\n7\t8\t9\thintO\n");
}